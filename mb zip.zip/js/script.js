const button = document.getElementById('butto');
button.onclick = function() {
  confirm ('Confirm checkout');
} 